---
name: FurniTech SaaS System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0d1c2f'
  on-tertiary-container: '#76859b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#d5e3fd'
  tertiary-fixed-dim: '#b9c7e0'
  on-tertiary-fixed: '#0d1c2f'
  on-tertiary-fixed-variant: '#3a485c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-tabular:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system embodies a modern, precise SaaS aesthetic built specifically for digital furniture manufacturing, wholesale logistics, and bespoke interior orchestration. The core tension sits between architectural digital precision and the tactile warmth of handcrafted woodworking. 

Targeted at furniture manufacturers, supply chain coordinators, and B2B interior clients, the interface prioritizes hyper-efficient data density, razor-sharp visual hygiene, and zero cognitive friction. The mood is disciplined, highly organized, and warm yet technological—avoiding generic enterprise blandness by pairing rich slate architectural grays with an artisanal warm amber accent.

The style merges crisp **Minimalism** with structural **Corporate Modern** rigor:
- Grounded, unyielding structure governed by strict horizontal and vertical alignments.
- Pure light mode environment that replicates clean architectural draftsmanship.
- Confident tactile accents representing woodcraft and precision engineering.
- Uncluttered workspaces where physical furniture renders and operational status flows take center stage.

## Colors

The palette is strictly calibrated for high-contrast legibility in a 100% light-mode operational interface. It balances high-performance digital neutrality with craft-inspired indicators.

### Core Palettes
- **Primary / Dominant Charcoal:** `#0F172A` (Slate 900). Anchors dominant typographic levels, key navigational surfaces, and active selection state indicators.
- **Secondary / Craft Accent:** `#D97706` (Amber 600). Signifies craftsmanship, decisive production triggers, primary interactive actions, and forward momentum. Interactive hover transitions down to `#B45309` (Amber 700).
- **Deep Steel / Secondary Text:** `#334155` (Slate 700). Governs secondary headings, detailed tabular values, active metadata, and icon definitions.
- **Muted Structural Slate:** `#64748B` (Slate 500) for captions, disabled states, and tertiary descriptive copy.

### Canvas & Structural Neutrals
- **Application Canvas Base:** `#F8FAFC` (Slate 50). Soft, light-absorbing structural field that eliminates glare across prolonged workstation sessions.
- **Surface Elevation / Cards:** `#FFFFFF` (White). Pure elevated surfaces providing crisp separation from canvas background.
- **Input Fill Surface:** `#F1F5F9` (Slate 100). Subtle inset tone for inputs, chips, and inactive tab containers.
- **Structural Outlines & Hairlines:** `#E2E8F0` (Slate 200). Strict 1px dividers defining modular table cells and component perimeters.

### Production Pipeline & Status Tokens
Status indicators operate on paired combinations of dark text/icons (`-600`) against tinted, high-legibility pills (`-100`):
- **Pending / Intake:** `#D97706` (Text/Icon) over `#FEF3C7` (Background / Amber 100).
- **In Production / Assembly:** `#2563EB` (Text/Icon) over `#DBEAFE` (Background / Blue 100).
- **QC / Finishing:** `#9333EA` (Text/Icon) over `#F3E8FF` (Background / Purple 100).
- **Ready / Dispatched / Settled:** `#16A34A` (Text/Icon) over `#DCFCE7` (Background / Green 100).
- **Cancelled / Rejected:** `#DC2626` (Text/Icon) over `#FEE2E2` (Background / Red 100).

## Typography

The type system is strictly standardized on **Inter**, optimized for clean geometric tracking and low-fatigue scanning across complex BOMs (Bills of Materials), dimensional blueprints, and inventory registers.

- **Tabular Numerics:** Enable `font-feature-settings: "tnum" 1, "cv05" 1, "cv11" 1` across all tables, order manifests, cut lists, pricing structures, and metric dashboards to guarantee vertical digit alignment.
- **Structural Tightening:** Negative tracking is systematically applied to headings (`-0.025em` to `-0.01em`) to maintain industrial authority without appearing decorative.
- **Uppercase Discipline:** The `label-sm` role is strictly designed for metadata sub-labels, table category headers, and SKU labels; pair it with `text-transform: uppercase` to maintain systematic structure.
- **Icons:** Integrated natively via **Google Material Symbols (Outlined)**, standardized to a `20px` bounding box for interactive elements and `16px` within dense tables or badges. Optical fill remains `FILL 0`, weight at `wght 400`, grade at `GRAD 0`.

## Layout & Spacing

The layout model is governed by an explicit 8-point spatial system (with 4px half-steps for micro-components such as badges, counters, and table cell heights). 

### Layout Model
- **Grid Architecture:** 12-column responsive fluid grid inside a maximum container width of `1600px` for desktop operational cockpits; 8-column for tablet viewports; 4-column fluid for mobile.
- **Gutters:** Standardized at `1.5rem` (24px) for desktop and tablet, stepping down to `1rem` (16px) on mobile viewports.
- **Outer Canvas Margins:** Desktop applications preserve a fixed `2rem` (32px) inset from shell frame bars, consolidating to `1rem` (16px) on mobile boundaries.
- **Component Packing:** Dense layouts (such as specifications or furniture components tables) utilize a strict vertical cadence of `space-xs` (4px) and `space-sm` (8px). Structural cards and content groups utilize `space-lg` (24px) inner offsets.

### Form Factor Behavior
- **Desktop (>= 1280px):** Fixed collateral navigation sidebar (`260px`), primary content region fluidly dynamically calculating span columns. Dual-pane inspection views allowed for CAD/furniture geometry previewing.
- **Tablet (768px - 1279px):** Collapsed iconography sidebar (`72px`), data tables convert low-priority operational columns to expansion dropdowns.
- **Mobile (< 768px):** Navigation transitions to an off-canvas drawer or bottom app bar. Spec tables convert into modular stack cards. Multi-stage workflows anchor confirmation buttons to the bottom viewport.

## Elevation & Depth

Visual hierarchy in this system relies on low-contrast structural outlines and subtle ambient light absorption rather than high, theatrical drop shadows. Because it is exclusively light mode, crisp contrast is achieved via calibrated border contrasts and delicate layering.

### Surface Elevation Hierarchy
- **Base Canvas (Level 0):** `#F8FAFC`. Floor layer holding all navigation and framework layout scaffolding.
- **Resting Structural Cards (Level 1):** `#FFFFFF` with a structural border `1px solid #E2E8F0` and `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.05)` (subtle `shadow-sm`).
- **Interactive / Hover Surface (Level 2):** Elevated card lift on hover or active flyout menu triggers: `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`. Border remains `#CBD5E1`.
- **Modals, Drawers & Command Overlays (Level 3):** `#FFFFFF` paired with an ambient tinted shadow: `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`. Backdrops use `#0F172A` at `40%` opacity with `backdrop-filter: blur(4px)`.

### Border Integrity
- All structural boundaries use `#E2E8F0` (Slate 200). 
- Avoid borderless card configurations: every modular widget, production stage container, and preview card maintains a defined 1px outline to retain drafting precision.

## Shapes

The geometry balances software precision with approachable, modern human factors:
- **Interactive Micro-Components (Buttons, Form Inputs, Badges, Tabs):** `12px` border-radius (`rounded-xl`). This delivers a soft, ergonomic touch-point without appearing cartoonish.
- **Structural Containers (Cards, Modals, Flyout Panels, Table Wrappers):** `16px` border-radius (`rounded-2xl`). Outlines curve cleanly, framing complex manufacturing specifications within soft visual enclosures.
- **Pill Badges (Status Pills, Metric Counters):** `9999px` full round for circular counters and singular pipeline phase chips.
- **Strict Geometric Rule:** Internal interactive elements embedded within a container must maintain a smaller radius than the parent (e.g., `12px` inputs inside a `16px` card) to preserve nested optical harmony.

## Components

### Buttons
- **Primary (CTA / Warm Amber):** Background `#D97706`, text `#FFFFFF`, radius `rounded-xl` (12px), height `40px` (`px-4`, `py-2`), `font-weight: 500`. Hover state transitions background to `#B45309` with a subtle elevation shift. Focus ring uses `2px solid #D97706` offset by `2px`.
- **Secondary (Slate Anchor):** Background `#0F172A`, text `#FFFFFF`, radius `rounded-xl` (12px). Hover state shifts to `#1E293B`.
- **Tertiary / Outline:** Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#334155`. Hover background `#F8FAFC`, border color `#CBD5E1`.
- **Icon Attachment:** Outlined Material Symbols positioned left or right with `20px` bounding box and `8px` spacing to label text.

### Form Inputs & Select Fields
- **Container:** Background `#F1F5F9` (Slate 100), border `1px solid transparent`, radius `rounded-xl` (12px), height `40px`, padding `0 14px`.
- **States:** Hover border shifts to `#CBD5E1`. Focused state turns background to `#FFFFFF`, border to `#0F172A` with `0 0 0 1px #0F172A`.
- **Placeholder / Text:** Text value is `#0F172A`, placeholder is `#94A3B8`.
- **Validation:** Invalid inputs display `#DC2626` border, `#FEF2F2` background, with supporting error label below in `label-sm`.

### Badges & Status Chips
- **Geometry:** Height `24px`, padding `0 10px`, radius `rounded-xl` (12px) or full pill, `font-weight: 500`, typography `label-sm`.
- **Status Variants:**
  - *Pending:* Background `#FEF3C7`, text `#D97706`, border `1px solid #FDE68A`.
  - *In Production:* Background `#DBEAFE`, text `#2563EB`, border `1px solid #BFDBFE`.
  - *QC / Finishing:* Background `#F3E8FF`, text `#9333EA`, border `1px solid #E9D5FF`.
  - *Ready / Settled:* Background `#DCFCE7`, text `#16A34A`, border `1px solid #BBF7D0`.
  - *Cancelled:* Background `#FEE2E2`, text `#DC2626`, border `1px solid #FECACA`.

### Cards & Modular Containers
- **Resting:** Background `#FFFFFF`, border `1px solid #E2E8F0`, radius `rounded-2xl` (16px), shadow `shadow-sm`. Interior padding defaults to `space-lg` (24px).
- **Header Structure:** Divided by a continuous `1px solid #F1F5F9` separator when containing dense table listings, housing `title-md` and actionable utility buttons.

### Data Tables & BOM Lists
- **Structure:** Encapsulated inside `rounded-2xl` bordered card envelopes. 
- **Header Row:** Background `#F8FAFC`, height `40px`, text in `label-sm` (`#64748B`), uppercase, tracking `0.04em`.
- **Data Rows:** Height `48px`, background alternating `#FFFFFF` and hover `#F8FAFC`, bottom border `1px solid #F1F5F9`. Primary identifiers rendered in `Inter` medium `#0F172A`, numeric columns configured with tabular figures (`font-feature-settings: "tnum"`).

### Checkboxes & Radio Elements
- **Checkbox:** `18px x 18px`, border `1.5px solid #CBD5E1`, radius `6px`. Checked state uses background `#0F172A`, border `#0F172A`, check icon `#FFFFFF`.
- **Radio:** `18px x 18px`, circular, border `1.5px solid #CBD5E1`. Selected state uses white interior ring surrounded by active `#0F172A` filling.

### Domain-Specific Components (FurniTech)
- **Cut List Spec Indicator:** Inset tabular cell module with physical grain icon, length × width × depth dimensions in `code-tabular`, and material badge (`Walnut Veneer`, `Steel 1018`, `Oak Solid`).
- **Pipeline Stage Stepper:** Horizontal connected node system showing progression: Intake -> Cutting -> Assembly -> Finishing/QC -> Logistics. Active stage highlighted in `#D97706`, completed in `#16A34A` with check mark, forthcoming in `#E2E8F0`.